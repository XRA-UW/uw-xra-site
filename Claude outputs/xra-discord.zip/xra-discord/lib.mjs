/* Shared pieces: a minimal Discord REST client and permission names.
   Plain fetch, no dependencies, so there is nothing third-party between your
   bot token and Discord. */

export const API = process.env.DISCORD_API_BASE || "https://discord.com/api/v10";

/* One clean line instead of a stack trace: every error this tool throws
   already says what failed and why. */
for (const ev of ["uncaughtException", "unhandledRejection"])
  process.on(ev, (err) => {
    console.error(`✗ ${err?.message ?? err}`);
    process.exit(1);
  });

export function env() {
  const token = process.env.DISCORD_TOKEN;
  const guildId = process.env.GUILD_ID;
  if (!token || !guildId) {
    console.error(
      "Missing DISCORD_TOKEN or GUILD_ID. Copy .env.example to .env, fill it in,\n" +
        "and run through npm (npm run export), which loads .env for you.",
    );
    process.exit(1);
  }
  return { token, guildId };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** One REST call. Waits and retries on rate limits; throws on other errors
 *  with Discord's own message, which is usually specific enough to act on. */
export async function api(token, method, route, body, reason) {
  for (let attempt = 0; attempt < 6; attempt++) {
    const headers = {
      Authorization: `Bot ${token}`,
      "User-Agent": "DiscordBot (xra-discord, 1.0)",
    };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    /* Shows in the server's audit log next to every change. */
    if (reason) headers["X-Audit-Log-Reason"] = encodeURIComponent(reason);
    const res = await fetch(`${API}${route}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (res.status === 429) {
      const data = await res.json().catch(() => ({}));
      await sleep(Math.ceil((data.retry_after ?? 1) * 1000) + 100);
      continue;
    }
    if (res.status === 204) return null;
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const msg = data?.message ?? res.statusText;
      const hint =
        res.status === 401
          ? " (bad token)"
          : res.status === 403
            ? " (the bot lacks a permission, or the role is above the bot's own role)"
            : "";
      throw new Error(`${method} ${route} -> ${res.status} ${msg}${hint}`);
    }
    return data;
  }
  throw new Error(`${method} ${route}: still rate limited after retries`);
}

/* Discord permission bits, by the names used in layout.json. Only the ones a
   server layout normally needs; add more from
   https://discord.com/developers/docs/topics/permissions if required. */
export const PERMS = {
  CREATE_INSTANT_INVITE: 0n,
  KICK_MEMBERS: 1n,
  BAN_MEMBERS: 2n,
  ADMINISTRATOR: 3n,
  MANAGE_CHANNELS: 4n,
  MANAGE_GUILD: 5n,
  ADD_REACTIONS: 6n,
  VIEW_AUDIT_LOG: 7n,
  PRIORITY_SPEAKER: 8n,
  STREAM: 9n,
  VIEW_CHANNEL: 10n,
  SEND_MESSAGES: 11n,
  SEND_TTS_MESSAGES: 12n,
  MANAGE_MESSAGES: 13n,
  EMBED_LINKS: 14n,
  ATTACH_FILES: 15n,
  READ_MESSAGE_HISTORY: 16n,
  MENTION_EVERYONE: 17n,
  USE_EXTERNAL_EMOJIS: 18n,
  CONNECT: 20n,
  SPEAK: 21n,
  MUTE_MEMBERS: 22n,
  MOVE_MEMBERS: 24n,
  CHANGE_NICKNAME: 26n,
  MANAGE_NICKNAMES: 27n,
  MANAGE_ROLES: 28n,
  MANAGE_WEBHOOKS: 29n,
  MANAGE_GUILD_EXPRESSIONS: 30n,
  USE_APPLICATION_COMMANDS: 31n,
  MANAGE_EVENTS: 33n,
  MANAGE_THREADS: 34n,
  CREATE_PUBLIC_THREADS: 35n,
  CREATE_PRIVATE_THREADS: 36n,
  SEND_MESSAGES_IN_THREADS: 38n,
  MODERATE_MEMBERS: 40n,
};

/* Permissions that let a role or bot take over or wreck the server. export
   flags any role holding one. */
export const DANGEROUS = [
  "ADMINISTRATOR",
  "MANAGE_GUILD",
  "MANAGE_ROLES",
  "MANAGE_CHANNELS",
  "MANAGE_WEBHOOKS",
  "BAN_MEMBERS",
  "KICK_MEMBERS",
  "MENTION_EVERYONE",
];

export function toBits(names = []) {
  let bits = 0n;
  for (const n of names) {
    const raw = /^BIT_(\d+)$/.exec(n);
    if (raw) bits |= 1n << BigInt(raw[1]);
    else if (n in PERMS) bits |= 1n << PERMS[n];
    else throw new Error(`Unknown permission "${n}" in layout.json`);
  }
  return bits;
}

/* Bits without a name above come out as BIT_<n> rather than being dropped,
   so exporting a role and applying it back never strips a permission. */
export function toNames(bits) {
  const b = BigInt(bits ?? 0);
  const byBit = new Map(Object.entries(PERMS).map(([n, i]) => [i, n]));
  const out = [];
  for (let i = 0n; i < 64n; i++) if (b & (1n << i)) out.push(byBit.get(i) ?? `BIT_${i}`);
  return out;
}

export const TYPE = { text: 0, voice: 2, category: 4, announcement: 5, stage: 13, forum: 15 };
export const TYPE_NAME = Object.fromEntries(Object.entries(TYPE).map(([k, v]) => [v, k]));

/** "#3A22FF" -> integer; Discord stores role colours as ints. */
export const colorInt = (hex) => (hex ? parseInt(hex.replace("#", ""), 16) : 0);
