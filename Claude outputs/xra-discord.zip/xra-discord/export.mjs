/* Read-only. Prints the server's current structure, flags every bot and every
   role with dangerous permissions, and writes two files:

     snapshot.json        raw API data, kept as a record of "before"
     layout.current.json  the same server in layout.json's format, with ids,
                          so a reorganization starts from what exists

   Nothing on the server changes. */

import fs from "node:fs";
import { api, env, toNames, DANGEROUS, TYPE_NAME } from "./lib.mjs";

const { token, guildId } = env();

const guild = await api(token, "GET", `/guilds/${guildId}`);
const roles = await api(token, "GET", `/guilds/${guildId}/roles`);
const channels = await api(token, "GET", `/guilds/${guildId}/channels`);

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
fs.writeFileSync(
  "snapshot.json",
  JSON.stringify({ exportedAt: stamp, guild: { id: guild.id, name: guild.name, features: guild.features }, roles, channels }, null, 2),
);

const roleName = (id) =>
  id === guildId ? "@everyone" : (roles.find((r) => r.id === id)?.name ?? `role:${id}`);

/* Overwrites by role name. Member-specific overwrites (type 1) are kept by id
   with a "user:" prefix so apply leaves them recognisable. */
function overwrites(ch) {
  const out = {};
  for (const o of ch.permission_overwrites ?? []) {
    const key = o.type === 0 ? roleName(o.id) : `user:${o.id}`;
    const allow = toNames(o.allow);
    const deny = toNames(o.deny);
    out[key] = { ...(allow.length && { allow }), ...(deny.length && { deny }) };
  }
  return out;
}

function channelEntry(ch) {
  const e = { id: ch.id, name: ch.name, type: TYPE_NAME[ch.type] ?? `type:${ch.type}` };
  if (ch.topic) e.topic = ch.topic;
  const ow = overwrites(ch);
  if (Object.keys(ow).length) e.permissions = ow;
  return e;
}

const byPos = (a, b) => a.position - b.position || a.id.localeCompare(b.id);
const cats = channels.filter((c) => c.type === 4).sort(byPos);
const kids = (parent) => channels.filter((c) => c.type !== 4 && (c.parent_id ?? null) === parent).sort(byPos);

const layout = {
  roles: roles
    .filter((r) => r.id !== guildId && !r.managed)
    .sort((a, b) => b.position - a.position)
    .map((r) => ({
      id: r.id,
      name: r.name,
      ...(r.color && { color: `#${r.color.toString(16).padStart(6, "0").toUpperCase()}` }),
      ...(r.hoist && { hoist: true }),
      ...(r.mentionable && { mentionable: true }),
      permissions: toNames(r.permissions),
    })),
  uncategorized: kids(null).map(channelEntry),
  categories: cats.map((c) => ({
    ...channelEntry(c),
    type: undefined,
    channels: kids(c.id).map(channelEntry),
  })),
};
fs.writeFileSync("layout.current.json", JSON.stringify(layout, null, 2));

/* ── Human-readable summary ─────────────────────────────────────────────── */
console.log(`${guild.name}  (${channels.length} channels, ${roles.length} roles)\n`);
const line = (ch, indent) => {
  const t = TYPE_NAME[ch.type] ?? ch.type;
  const priv = (ch.permission_overwrites ?? []).some(
    (o) => o.id === guildId && BigInt(o.deny) & (1n << 10n),
  );
  console.log(`${indent}${t === "voice" ? "🔊" : "#"} ${ch.name}  [${t}${priv ? ", private" : ""}]`);
};
for (const ch of kids(null)) line(ch, "  ");
for (const c of cats) {
  console.log(`\n▸ ${c.name.toUpperCase()}`);
  for (const ch of kids(c.id)) line(ch, "  ");
}

console.log("\nRoles, highest first:");
for (const r of [...roles].sort((a, b) => b.position - a.position)) {
  if (r.id === guildId) continue;
  const danger = toNames(r.permissions).filter((p) => DANGEROUS.includes(p));
  const bot = r.managed ? (r.tags?.bot_id ? `  [BOT ${r.tags.bot_id}]` : "  [integration]") : "";
  console.log(`  ${r.name}${bot}${danger.length ? `  ⚠ ${danger.join(", ")}` : ""}`);
}
const everyoneDanger = toNames(roles.find((r) => r.id === guildId)?.permissions).filter((p) =>
  DANGEROUS.includes(p),
);
if (everyoneDanger.length) console.log(`  @everyone  ⚠ ${everyoneDanger.join(", ")}`);

const bots = roles.filter((r) => r.managed && r.tags?.bot_id);
if (bots.length) {
  console.log("\nBots in this server (from their managed roles):");
  for (const r of bots) {
    const danger = toNames(r.permissions).filter((p) => DANGEROUS.includes(p));
    console.log(
      `  ${r.name}  id ${r.tags.bot_id}  ${danger.length ? `⚠ can ${danger.join(", ")}` : "no dangerous permissions"}`,
    );
  }
  console.log(
    "  A bot can also get rights through other roles it holds; check those in Server Settings > Members.",
  );
}

console.log("\nWrote snapshot.json and layout.current.json. Nothing on the server changed.");
