/* Makes the server match a layout file.

     npm run plan                 # dry run: prints what would change
     npm run apply                # does it
     npm run plan -- other.json   # a different layout file

   Rules, chosen so a mistake costs little:
   - Never deletes a channel or role. Anything not in the layout is listed as
     "not in layout" and left alone; delete it by hand once you are sure.
   - Matching: an entry with "id" targets that exact channel or role (export
     writes ids, so renaming is just editing "name"). Without an id, it
     matches by "rename_from", then by name. No match means create.
   - Permissions listed on a channel are set exactly for the roles listed.
     Roles not listed keep whatever they have. Set a role to null to remove
     its overwrite.
   - Bot-managed roles are never edited. */

import fs from "node:fs";
import { api, env, toBits, toNames, colorInt, TYPE, TYPE_NAME } from "./lib.mjs";

const args = process.argv.slice(2);
const APPLY = args.includes("--apply");
const file = args.find((a) => !a.startsWith("--")) ?? "layout.json";

const { token, guildId } = env();
const layout = JSON.parse(fs.readFileSync(file, "utf8"));
const REASON = `xra-discord apply ${file}`;

const roles = await api(token, "GET", `/guilds/${guildId}/roles`);
const channels = await api(token, "GET", `/guilds/${guildId}/channels`);

const ops = []; // { text, run: async () => {} }
const notes = [];
const op = (text, run) => ops.push({ text, run });

/* ── Roles ──────────────────────────────────────────────────────────────── */

/* name -> id, filled with live roles now and created roles during the run. */
const roleIds = new Map([["@everyone", guildId]]);
for (const r of roles) if (r.id !== guildId && !roleIds.has(r.name)) roleIds.set(r.name, r.id);
const usedRoles = new Set();

for (const want of layout.roles ?? []) {
  let live =
    (want.id && roles.find((r) => r.id === want.id)) ||
    (want.rename_from && roles.find((r) => r.name === want.rename_from && !usedRoles.has(r.id))) ||
    roles.find((r) => r.name === want.name && !usedRoles.has(r.id));
  if (want.id && !live) throw new Error(`Role id ${want.id} ("${want.name}") is not on the server.`);

  if (live?.managed) {
    notes.push(`role "${live.name}" is managed by a bot or integration; skipped`);
    continue;
  }
  const body = { name: want.name };
  if ("color" in want) body.color = colorInt(want.color);
  if ("hoist" in want) body.hoist = !!want.hoist;
  if ("mentionable" in want) body.mentionable = !!want.mentionable;
  if ("permissions" in want) body.permissions = toBits(want.permissions).toString();

  if (!live) {
    op(`+ create role "${want.name}"`, async () => {
      const r = await api(token, "POST", `/guilds/${guildId}/roles`, body, REASON);
      roleIds.set(want.name, r.id);
    });
    roleIds.set(want.name, `(new:${want.name})`);
    continue;
  }
  usedRoles.add(live.id);
  roleIds.set(want.name, live.id);
  const changes = [];
  if (body.name !== live.name) changes.push(`rename "${live.name}" -> "${body.name}"`);
  if ("color" in body && body.color !== live.color) changes.push(`color ${want.color}`);
  if ("hoist" in body && body.hoist !== live.hoist) changes.push(`hoist ${body.hoist}`);
  if ("mentionable" in body && body.mentionable !== live.mentionable)
    changes.push(`mentionable ${body.mentionable}`);
  if ("permissions" in body && body.permissions !== String(live.permissions)) {
    const before = new Set(toNames(live.permissions));
    const after = new Set(toNames(body.permissions));
    const add = [...after].filter((p) => !before.has(p));
    const rm = [...before].filter((p) => !after.has(p));
    changes.push(`permissions ${[...add.map((p) => `+${p}`), ...rm.map((p) => `-${p}`)].join(" ")}`);
  }
  if (changes.length)
    op(`~ role "${want.name}": ${changes.join("; ")}`, () =>
      api(token, "PATCH", `/guilds/${guildId}/roles/${live.id}`, body, REASON),
    );
}

/* ── Channels ───────────────────────────────────────────────────────────── */

const TEXTLIKE = new Set([TYPE.text, TYPE.announcement, TYPE.forum]);
/* Discord stores text channel names lowercased with hyphens for spaces;
   normalise so "Find a Team" in the layout matches "find-a-team" live. */
const norm = (name, type) =>
  TEXTLIKE.has(type) ? name.trim().toLowerCase().replace(/\s+/g, "-") : name.trim();
const compatible = (a, b) =>
  a === b || (new Set([a, b]).size === 2 && [a, b].every((t) => t === TYPE.text || t === TYPE.announcement));

const usedCh = new Set();
const chIds = new Map(); // layout entry -> live or created id

function findChannel(want, type, parentId) {
  if (want.id) {
    const c = channels.find((c) => c.id === want.id);
    if (!c) throw new Error(`Channel id ${want.id} ("${want.name}") is not on the server.`);
    return c;
  }
  const free = channels.filter((c) => !usedCh.has(c.id) && compatible(c.type, type));
  const named = (n) => free.filter((c) => c.name === norm(n, type));
  for (const n of [want.rename_from, want.name].filter(Boolean)) {
    const hits = named(n);
    const hit = hits.find((c) => (c.parent_id ?? null) === parentId) ?? hits[0];
    if (hit) return hit;
  }
  return null;
}

function targetOf(key) {
  if (key.startsWith("user:")) return { id: key.slice(5), type: 1 };
  const id = roleIds.get(key);
  if (!id) throw new Error(`Permission target "${key}" is not a role on the server or in the layout.`);
  return { id, type: 0 };
}
const resolveId = (id) => (id.startsWith("(new:") ? roleIds.get(id.slice(5, -1)) : id);

function overwriteOps(label, want, live, getChannelId) {
  for (const [key, spec] of Object.entries(want.permissions ?? {})) {
    const t = targetOf(key);
    const existing = live?.permission_overwrites?.find((o) => o.id === t.id);
    if (spec === null) {
      if (existing)
        op(`~ ${label}: remove overwrite for ${key}`, () =>
          api(token, "DELETE", `/channels/${getChannelId()}/permissions/${t.id}`, undefined, REASON),
        );
      continue;
    }
    const allow = toBits(spec.allow).toString();
    const deny = toBits(spec.deny).toString();
    if (existing && existing.allow === allow && existing.deny === deny) continue;
    const desc = [...(spec.allow ?? []).map((p) => `+${p}`), ...(spec.deny ?? []).map((p) => `-${p}`)];
    op(`~ ${label}: ${key} ${desc.join(" ") || "(neutral)"}`, () =>
      api(
        token,
        "PUT",
        `/channels/${getChannelId()}/permissions/${resolveId(t.id)}`,
        { allow, deny, type: t.type },
        REASON,
      ),
    );
  }
}

function planChannel(want, type, parentEntry, label) {
  const parentLiveId = parentEntry ? (chIds.get(parentEntry) ?? null) : null;
  const live = findChannel(want, type, parentLiveId?.startsWith?.("(new") ? null : parentLiveId);
  const name = norm(want.name, type);
  const parentIdNow = () => (parentEntry ? chIds.get(parentEntry) : null);
  const where = parentEntry ? ` in "${parentEntry.name}"` : "";

  if (!live) {
    chIds.set(want, `(new)`);
    op(`+ create ${label} [${TYPE_NAME[type]}]${where}`, async () => {
      const c = await api(
        token,
        "POST",
        `/guilds/${guildId}/channels`,
        {
          name,
          type,
          ...(type !== TYPE.category && { parent_id: parentIdNow() }),
          ...(want.topic && { topic: want.topic }),
        },
        REASON,
      );
      chIds.set(want, c.id);
    });
    overwriteOps(label, want, null, () => chIds.get(want));
    return;
  }

  usedCh.add(live.id);
  chIds.set(want, live.id);
  const patch = {};
  const changes = [];
  if (live.name !== name) {
    patch.name = name;
    changes.push(`rename from "${live.name}"`);
  }
  if (type !== live.type) {
    patch.type = type;
    changes.push(`type ${TYPE_NAME[live.type]} -> ${TYPE_NAME[type]}`);
  }
  if ("topic" in want && (want.topic ?? "") !== (live.topic ?? "")) {
    patch.topic = want.topic ?? "";
    changes.push("topic");
  }
  if (type !== TYPE.category && (live.parent_id ?? null) !== parentLiveId) {
    changes.push(parentEntry ? `move to "${parentEntry.name}"` : "move out of its category");
  }
  if (changes.length)
    op(`~ ${label}: ${changes.join("; ")}`, () => {
      const body = { ...patch };
      if (type !== TYPE.category) body.parent_id = parentIdNow();
      return api(token, "PATCH", `/channels/${live.id}`, body, REASON);
    });
  overwriteOps(label, want, live, () => live.id);
}

const catsWant = layout.categories ?? [];
for (const cat of catsWant) planChannel(cat, TYPE.category, null, `category "${cat.name}"`);
const childLabel = (ch, type) =>
  `${type === TYPE.voice || type === TYPE.stage ? "🔊" : "#"}${norm(ch.name, type)}`;
for (const ch of layout.uncategorized ?? []) {
  const type = TYPE[ch.type ?? "text"];
  planChannel(ch, type, null, childLabel(ch, type));
}
for (const cat of catsWant)
  for (const ch of cat.channels ?? []) {
    const type = TYPE[ch.type ?? "text"];
    if (type === undefined) throw new Error(`Unknown channel type "${ch.type}" for ${ch.name}`);
    planChannel(ch, type, cat, childLabel(ch, type));
  }

/* ── Order ──────────────────────────────────────────────────────────────── */
/* Layout order wins for everything in the layout. Channels the layout does
   not mention keep their relative order, after the managed ones. */
function positionsFor(entries, parentId, isCat) {
  const managed = entries.map((e) => chIds.get(e));
  const others = channels
    .filter(
      (c) =>
        !managed.includes(c.id) &&
        (isCat ? c.type === TYPE.category : c.type !== TYPE.category && (c.parent_id ?? null) === parentId),
    )
    .sort((a, b) => a.position - b.position)
    .map((c) => c.id);
  return [...managed, ...others];
}
function currentOrder(ids) {
  const live = ids.map((id) => channels.find((c) => c.id === id)).filter(Boolean);
  return [...live].sort((a, b) => a.position - b.position).map((c) => c.id);
}
const anyNew = () => [...chIds.values()].some((v) => v === "(new)");
let reorder = anyNew();
const orderSets = () => [
  positionsFor(catsWant, null, true),
  positionsFor(layout.uncategorized ?? [], null, false),
  ...catsWant.map((cat) => positionsFor(cat.channels ?? [], chIds.get(cat), false)),
];
if (!reorder)
  reorder = orderSets().some((ids) => ids.join() !== currentOrder(ids).join());
/* Categories in the layout go first, in layout order, then the rest. For a
   partial layout (one event category) that puts it at the top of the server. */
const catOrder = [
  ...catsWant.map((c) => c.name),
  ...positionsFor(catsWant, null, true)
    .slice(catsWant.length)
    .map((id) => channels.find((c) => c.id === id)?.name),
];
if (reorder)
  op(`↕ set order; categories: ${catOrder.join(" > ")}`, () => {
    const body = orderSets().flatMap((ids) => ids.map((id, i) => ({ id, position: i })));
    return api(token, "PATCH", `/guilds/${guildId}/channels`, body, REASON);
  });

/* ── Report ─────────────────────────────────────────────────────────────── */
const leftovers = channels.filter((c) => !usedCh.has(c.id));
const leftoverRoles = roles.filter(
  (r) => r.id !== guildId && !r.managed && !usedRoles.has(r.id) && (layout.roles ?? []).length,
);

console.log(`${APPLY ? "Applying" : "Plan for"} ${file}:\n`);
if (!ops.length) console.log("  Nothing to change. The server already matches.");
/* In apply mode each change prints as it lands, below, instead. */
if (!APPLY) for (const o of ops) console.log(`  ${o.text}`);
for (const n of notes) console.log(`  · ${n}`);
if (leftovers.length) {
  console.log("\nNot in layout (left as is):");
  for (const c of leftovers) console.log(`  ${TYPE_NAME[c.type] === "category" ? "▸" : "#"}${c.name}`);
}
if (leftoverRoles.length) {
  console.log("\nRoles not in layout (left as is):");
  for (const r of leftoverRoles) console.log(`  ${r.name}`);
}

if (!APPLY) {
  if (ops.length) console.log("\nDry run. Nothing changed. Run `npm run apply` to make these changes.");
  process.exit(0);
}

let done = 0;
if (ops.length) console.log("");
try {
  for (const o of ops) {
    await o.run();
    done++;
    console.log(`  ✓ ${o.text}`);
  }
  console.log(`\nDone: ${done} change${done === 1 ? "" : "s"}. Each shows in the server audit log.`);
} catch (err) {
  console.error(`\n✗ Stopped after ${done} of ${ops.length} changes:\n  ${err.message}`);
  console.error("  Fix the cause and run `npm run plan` again; finished steps are not repeated.");
  process.exit(1);
}
