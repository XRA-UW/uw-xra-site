# xra-discord

Export the XRA Discord server's structure and reorganize it from a layout
file. Plain Node, no dependencies: nothing third-party ever sees the bot token.

- `npm run export`: read-only. Prints the server tree, flags every bot and every
  role with dangerous permissions, and writes `snapshot.json` (a record of
  "before") and `layout.current.json` (the server in layout format, with ids).
- `npm run plan`: dry run. Prints every change `layout.json` would make.
- `npm run apply`: makes those changes. Each shows in the server audit log as
  "xra-discord apply".

It **never deletes** a channel or role. Anything not in the layout is listed as
"not in layout" and left alone; delete it by hand once you are sure.

Requires Node 20.6 or newer (`node -v`).

## One-time setup (about 10 minutes)

1. **Create the bot.** Go to https://discord.com/developers/applications, click
   New Application, and name it something like "XRA Admin". Under **Bot**:
   - Turn **off** "Public Bot", so only you can add it to servers. If Discord
     refuses with "Private application cannot have a default authorization
     link", first go to the **Installation** tab, set Install Link to
     **None**, save, then turn Public Bot off. Step 4 below still works.
   - Leave all three Privileged Gateway Intents off. This tool does not need them.
   - Click **Reset Token** and copy the token.
2. **Save the token.** In this folder, copy `.env.example` to `.env` and paste
   the token after `DISCORD_TOKEN=`. Never commit `.env`, paste it in chat, or
   put this folder inside the public website repo.
3. **Get the server ID.** In Discord: User Settings > Advanced > turn on
   Developer Mode. Right-click the XRA server icon > Copy Server ID. Paste it
   after `GUILD_ID=`.
4. **Invite the bot.** In the Developer Portal: OAuth2 > URL Generator. Tick the
   scope `bot`, then the permission **Administrator**. Open the generated URL
   and add the bot to the XRA server.
   - Why Administrator: to set a channel permission, Discord requires the bot
     to hold that permission itself, and to see private channels. Narrower
     permissions fail partway through a reorganization.
   - The trade-off: anyone with the token can do anything on the server. So
     keep the bot only while you are reorganizing, then kick it (Server
     Settings > Members, or Integrations). If the token ever leaks, click
     Reset Token immediately; the old one stops working.
5. **Move the bot's role to the top.** Server Settings > Roles: drag the bot's
   role ("XRA Admin") above every role it should edit. Discord blocks a bot
   from editing roles at or above its own.

## Workflow

```sh
npm run export      # look first; nothing changes
npm run plan        # what layout.json would do
npm run apply       # do it
```

For the full reorganization, start from what exists:

1. Run `npm run export`.
2. Copy `layout.current.json` to a new file, e.g. `reorg.json`, and edit it:
   rename, reorder, move channels between categories, change permissions.
   Entries keep their `id`, so changing `name` renames in place instead of
   creating a new channel.
3. Run `npm run plan -- reorg.json` until the plan is what you want, then
   `npm run apply -- reorg.json`.
4. Run `npm run plan -- reorg.json` again. It should say "Nothing to change".

If an apply stops partway (a permission error, say), fix the cause and run it
again. Finished steps are already done, so they do not repeat.

## Layout format

```jsonc
{
  "roles": [
    // Optional "id" (from export) pins an exact role. "permissions" is the
    // full list of server-wide permissions; leave it out to not touch them.
    { "name": "Mentor 2027", "color": "#00C389", "hoist": true, "permissions": [] }
  ],
  "uncategorized": [ /* channels with no category, same shape as below */ ],
  "categories": [
    {
      "name": "Bark to Reality 2027",
      "channels": [
        {
          "name": "mentors",
          "type": "text",               // text | voice | forum | announcement | stage
          "topic": "Shift swaps",
          "rename_from": "old-name",    // optional: rename an existing channel
          "permissions": {
            "@everyone": { "deny": ["VIEW_CHANNEL"] },
            "Mentor 2027": { "allow": ["VIEW_CHANNEL"] },
            "Old Role": null            // null removes that role's override
          }
        }
      ]
    }
  ]
}
```

- **Order:** layout order is the order on the server. Categories in the
  layout go first, so a layout with only the hackathon category puts it at
  the top. Channels not in the layout keep their order, after the listed ones.
- **Permissions:** a channel's `permissions` sets exactly the roles listed.
  Roles not listed keep what they have. Names are in `lib.mjs` (`PERMS`).
  Permissions without a name there appear as `BIT_<n>` and round-trip safely.
- **Bot roles** are never edited.
- **Announcement channels** need Community enabled on the server (Server
  Settings > Enable Community). Without it, creating one fails with a clear
  error; change the type to `text` or turn Community on.
